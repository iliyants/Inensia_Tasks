﻿using Newtonsoft.Json;
using Task1;

namespace MyApp
{
    internal class Startup
    {
        static void Main()
        {

            var filePath = File.ReadAllText(Path.GetFullPath("../../../input.txt"));

            var movieStars = JsonConvert.DeserializeObject<MovieStar[]>(filePath);

            foreach (var movieStar in movieStars)
            {
                Console.WriteLine(movieStar.ToString());
            }

        }
    }
}